</div>
</body>

<script src="<?php staticFiles('js/mdui.min.js') ?>"></script>
<script src="<?php staticFiles('js/setting.min.js') ?>"></script>